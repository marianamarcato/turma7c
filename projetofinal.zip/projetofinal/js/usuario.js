function exibirUsuario(){
    var strusuario = localStorage.getItem("user");
    if (strusuario){
        var usuario = JSON.parse(localStorage.getItem("user"));
        document.getElementById("foto").innerHTML = "<img alt='Sem foto' width='25%' src=images/" + usuario.foto + ">";
        document.getElementById("dados").innerHTML = 
        "<h3>Nome: " + usuario.nome + "<br>(" + usuario.email + ") <br>ID: " + usuario.id + "</h3>";
    }else{
        window.location="login.html";
    }
}